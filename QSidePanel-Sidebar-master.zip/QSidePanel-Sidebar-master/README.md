# Qt Side Panel widget

![demonstration](./images/side_panel.gif)

## Usage

Add to your `*.pro` file next line: `include(<path/to>/QSidePanel/q_side_panel.pri)`

## Examples

See [MainWindow.cpp](./MainWindow.cpp)
